// Provide persistence solution code here
const persistSubmittedContact = (contact) => {
    var xhr = new XMLHttpRequest();
    xhr.onload = () => {
        console.log(`Successful: ${xhr.status} ${xhr.response}`);
    };
    xhr.onerror = () => {
        console.error('Something went wrong.');
    }
    xhr.open('POST', 'http://localhost:3000/contacts', true);
    xhr.send(JSON.stringify(contact));
    
}


// Code to show the persisted data
const showPersistedData = () => {
    var xhr = new XMLHttpRequest();
    xhr.onload = () => {
        console.log(`Successful: ${xhr.status} ${xhr.response}`);
    };
    xhr.onerror = () => {
        console.error('Something went wrong.');
    }
    xhr.open("GET", 'http://localhost:3000/contacts');
    xhr.send();
}

module.exports = { persistSubmittedContact, showPersistedData }

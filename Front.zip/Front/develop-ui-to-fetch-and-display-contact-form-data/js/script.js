// put validation code here
// put validation code here

const submitContact = () => {
    
    let contact = {
        firstName: document.getElementById('firstname').value,
        lastName: document.getElementById('lastname').value,
        email: document.getElementById('email').value,
        homeNo: document.getElementById('homeNo').value,
        workNo: document.getElementById('workNo').value,
        notes: document.getElementById('notes').value
    }
    console.log(JSON.stringify(contact));
    if (contact.firstName == null && contact.lastName == null && contact.email == null && contact.homeNo == null && contact.workNo == null && contact.notes == null)
        return false;

    persistSubmittedContact(contact);
    return true;
}


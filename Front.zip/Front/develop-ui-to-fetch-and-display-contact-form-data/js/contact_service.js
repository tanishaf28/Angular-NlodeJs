const axios = require('axios');
let url = "http://localhost:3000/contacts"
// put the solution code to persist and fetch data here

/*
    persistSumittedContact() should contain code to persist given contact to server
    use axios to call the post method and persist data
    ensure the return from axios handles both success and error
    the posted data should be displayed on the browser as well.
*/
const persistSubmittedContact = (contact) => {
    axios.post(url,{
        firstName: contact.firstName,
        lastName: contact.lastName,
        email: contact.email,
        homeNo: contact.homeNo,
        workNo: contact.workNo,
        notes: contact.notes
    })
    .then(reponse =>{
        console.log(reponse);
    });

}

/*
    getDetails() should contain code to fetch details of contact for the given contact-id from server
    use axios to call the get method and fetch data
    ensure the return from axios handles both success and error
    the fetched data should be displayed on the browser in a modal dialog.
*/
const getDetails = (id) => {
    let promise = axios.get(`${url}/${id}`);
    promise.then(response => {
        let contact = response.data;
        document.getElementById('contact-data').innerHTML = `
        <li><strong>${contact.firstName} ${contact.lastName}</strong></li>
        <li>Home ${contact.homeNo} </li>
        <li>Work ${contact.workNo} </li>
        <li>Birthdate ${contact.birthDate}</li>
        <li>Company ${contact.company}</li>
        <li>Job Title ${contact.jobTitle}</li>
        <li>${contact.notes}</li>`;
    })

}

/*
    showPersistedData() should contain code to fetch details of all existing contacts from server
    use axios to call the get method and fetch data
    ensure the return from axios handles both success and error
    the fetched data should be displayed on the browser
*/
const showPersistedData = () => {
    let promise = axios.get(url);

    promise.then(response => {

        // let tableBody = document.getElementById('contact-list').getElementsByTagName('table')[0].getElementsByTagName('tbody')[0];
        let contacts = response.data.sort((a, b) => {
            if (a.firstName > b.firstName)
                return 1;
            else
                return -1;
        })
        contacts.forEach(contact => {

                    tableBody.innerHTML += `<tr>
              <td>${contact.firstName}</td>
              <td>${contact.lastName}</td>
              <td>${contact.email}</td>
              <td>${contact.homeNo}</td>
              <td><button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal" onmousedown='getDetails(${contact.id})'>+</button></td>
              </tr>`
        })
    })

}
//showPersistedData(); //uncomment this code to display the existing contacts on browser


module.exports = { persistSubmittedContact, showPersistedData, getDetails }

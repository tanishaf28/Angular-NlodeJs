/*
User Story : Contact Submission
Scenario 1 : All Details correctly provided
Given: contact
When: contact is submitted
Then: return true
And: persistSubmittedContact() is called

Scenario 2 : Invalid Details provided
Given: contact
When: contact is submitted
Then: return false
And: displayValidationSummary() is called
And: displayIndividualErrorMessages() is called
*/
describe("Contact Submission", function () {
    it("provides all correct details", () => {
        if (expect(submitContact).toBe(true)) {
            expect(persistSubmittedContact).tohavebeencalled;
        }

    });
    it("provides invalid details", () => {
        if (expect(submitContact).toBe(true)) {
            expect(displayValidationSummary).tohavebeencalled;
            expect(displayIndividualErrorMessages).tohave.beencalled;
        }
    });
})
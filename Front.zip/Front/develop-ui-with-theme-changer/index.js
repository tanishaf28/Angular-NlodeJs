function changeTheme(event) {
    let id = event.target.id;
    if (id == "bright") {
        document.body.style.backgroundColor = "lightyellow";
        document.body.style.color = "darkgreen";
    }
    if (id == "cool") {
        document.body.style.backgroundColor = "lightgray";
        document.body.style.color = "indigo";
    }
    if (id == "fiery") {
        document.body.style.backgroundColor = "chocolate";
        document.body.style.color = "lightgoldenyellow";
    }
}

module.exports = changeTheme